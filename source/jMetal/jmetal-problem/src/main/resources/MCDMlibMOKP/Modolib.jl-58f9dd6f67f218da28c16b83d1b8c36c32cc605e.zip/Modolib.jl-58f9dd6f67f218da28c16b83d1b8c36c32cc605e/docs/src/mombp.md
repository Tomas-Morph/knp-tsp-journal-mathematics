# Multiobjective Mixed Binary Programs #

```@docs
read_mombp_aritra_instance
read_mombp_aritra_non_dom_pts
read_mombp_aritra
```
