# Reading and Writing Instances #

## Reading and Writing a `BOBPInstance` ##

```@docs
write_bobpinstance
read_bobpinstance
```
